package com.genobee.compass

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.view.Surface
import androidx.core.content.ContextCompat
import kotlin.math.sqrt

/**
 * One frame of compass state. Angles are degrees; azimuths are 0..360 clockwise from north.
 */
data class CompassReading(
    val magneticAzimuth: Float = 0f,
    val trueAzimuth: Float = 0f,
    val declination: Float = 0f,
    val hasDeclination: Boolean = false,
    val pitch: Float = 0f,
    val roll: Float = 0f,
    val fieldStrength: Float = 0f,
    val calibration: Int = SensorManager.SENSOR_STATUS_UNRELIABLE
)

class CompassEngine(
    private val context: Context,
    private val onReading: (CompassReading) -> Unit
) : SensorEventListener {

    private val sensorManager =
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    private val rotationSensor: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

    private val magnetometer: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    val isSupported: Boolean = rotationSensor != null

    private val rotationMatrix = FloatArray(9)
    private val remapped = FloatArray(9)
    private val orientation = FloatArray(3)

    private var smoothedAzimuth = Float.NaN
    private var declination = 0f
    private var hasDeclination = false
    private var fieldStrength = 0f
    private var calibration = SensorManager.SENSOR_STATUS_UNRELIABLE
    private var lastEmit = 0L
    private var locationRequested = false

    fun start() {
        rotationSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        magnetometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        if (sensor?.type == Sensor.TYPE_MAGNETIC_FIELD) {
            calibration = accuracy
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_MAGNETIC_FIELD -> {
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                fieldStrength = sqrt(x * x + y * y + z * z)
                calibration = event.accuracy
            }

            Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)

                // Compensate for how the screen is mounted relative to the sensor axes.
                val rotation = try {
                    ContextCompat.getDisplayOrDefault(context).rotation
                } catch (e: Exception) {
                    Surface.ROTATION_0
                }
                val axes = when (rotation) {
                    Surface.ROTATION_90 ->
                        SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
                    Surface.ROTATION_180 ->
                        SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
                    Surface.ROTATION_270 ->
                        SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
                    else ->
                        SensorManager.AXIS_X to SensorManager.AXIS_Y
                }
                SensorManager.remapCoordinateSystem(
                    rotationMatrix, axes.first, axes.second, remapped
                )
                SensorManager.getOrientation(remapped, orientation)

                val raw = normalize(Math.toDegrees(orientation[0].toDouble()).toFloat())
                smoothedAzimuth =
                    if (smoothedAzimuth.isNaN()) raw
                    else lerpAngle(smoothedAzimuth, raw, SMOOTHING)

                val pitch = Math.toDegrees(orientation[1].toDouble()).toFloat()
                val roll = Math.toDegrees(orientation[2].toDouble()).toFloat()

                val now = System.currentTimeMillis()
                if (now - lastEmit >= EMIT_INTERVAL_MS) {
                    lastEmit = now
                    onReading(
                        CompassReading(
                            magneticAzimuth = smoothedAzimuth,
                            trueAzimuth = normalize(smoothedAzimuth + declination),
                            declination = declination,
                            hasDeclination = hasDeclination,
                            pitch = pitch,
                            roll = roll,
                            fieldStrength = fieldStrength,
                            calibration = calibration
                        )
                    )
                }
            }
        }
    }

    /**
     * True north differs from magnetic north by the local declination, which in Canada can be
     * more than 20 degrees. Needs a position fix; without one the app reports magnetic north.
     */
    fun refreshDeclination() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return

        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return

        var best: Location? = null
        for (provider in lm.getProviders(true)) {
            val fix = try {
                lm.getLastKnownLocation(provider)
            } catch (e: SecurityException) {
                null
            }
            val current = best
            if (fix != null && (current == null || fix.time > current.time)) best = fix
        }

        if (best != null) {
            applyLocation(best)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !locationRequested) {
            locationRequested = true
            val provider = when {
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) ->
                    LocationManager.NETWORK_PROVIDER
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ->
                    LocationManager.GPS_PROVIDER
                else -> null
            } ?: return
            try {
                lm.getCurrentLocation(provider, null, context.mainExecutor) { fix ->
                    if (fix != null) applyLocation(fix)
                }
            } catch (e: SecurityException) {
                // Permission revoked between the check and the call; stay on magnetic north.
            }
        }
    }

    private fun applyLocation(location: Location) {
        declination = GeomagneticField(
            location.latitude.toFloat(),
            location.longitude.toFloat(),
            location.altitude.toFloat(),
            System.currentTimeMillis()
        ).declination
        hasDeclination = true
    }

    companion object {
        private const val SMOOTHING = 0.18f
        private const val EMIT_INTERVAL_MS = 16L

        fun normalize(degrees: Float): Float = ((degrees % 360f) + 360f) % 360f

        /** Interpolates the short way round so 359 -> 1 does not spin the dial backwards. */
        fun lerpAngle(from: Float, to: Float, factor: Float): Float {
            val delta = ((to - from + 540f) % 360f) - 180f
            return normalize(from + delta * factor)
        }

        fun cardinal(degrees: Float): String {
            val points = arrayOf(
                "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
                "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"
            )
            val index = ((normalize(degrees) / 22.5f) + 0.5f).toInt() % 16
            return points[index]
        }
    }
}
