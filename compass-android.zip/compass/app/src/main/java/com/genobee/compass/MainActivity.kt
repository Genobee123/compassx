package com.genobee.compass

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val readingState = mutableStateOf(CompassReading())
    private val locationGranted = mutableStateOf(false)
    private lateinit var engine: CompassEngine

    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        locationGranted.value = granted
        if (granted) engine.refreshDeclination()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        engine = CompassEngine(applicationContext) { reading ->
            readingState.value = reading
        }

        locationGranted.value = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        // A compass you have to keep waking up is not much use in the field.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContent {
            CompassApp(
                reading = readingState.value,
                supported = engine.isSupported,
                hasLocationPermission = locationGranted.value,
                onRequestLocation = {
                    locationPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        engine.start()
        engine.refreshDeclination()
    }

    override fun onPause() {
        super.onPause()
        engine.stop()
    }
}
