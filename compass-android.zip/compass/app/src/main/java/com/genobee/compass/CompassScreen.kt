package com.genobee.compass

import android.graphics.Typeface
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import android.graphics.Paint as NativePaint

private val Night = Color(0xFF070B12)
private val Housing = Color(0xFF0F1926)
private val Brass = Color(0xFFC9963C)
private val BrassDim = Color(0xFF5E4A22)
private val Bone = Color(0xFFEAE4D4)
private val NorthRed = Color(0xFFD24B3E)
private val Good = Color(0xFF5FB89A)
private val Warn = Color(0xFFE0A33E)

@Composable
fun CompassApp(
    reading: CompassReading,
    supported: Boolean,
    hasLocationPermission: Boolean,
    onRequestLocation: () -> Unit
) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Night,
            surface = Housing,
            primary = Brass,
            onPrimary = Night,
            onBackground = Bone,
            onSurface = Bone
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Night)
        ) {
            if (!supported) {
                Text(
                    text = "This phone has no rotation-vector sensor, so it cannot report a heading.",
                    color = Bone,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp),
                    textAlign = TextAlign.Center
                )
            } else {
                CompassScreen(reading, hasLocationPermission, onRequestLocation)
            }
        }
    }
}

@Composable
private fun CompassScreen(
    reading: CompassReading,
    hasLocationPermission: Boolean,
    onRequestLocation: () -> Unit
) {
    var useTrueNorth by remember { mutableStateOf(true) }
    val referenceIsTrue = useTrueNorth && reading.hasDeclination
    val heading = if (referenceIsTrue) reading.trueAzimuth else reading.magneticAzimuth

    val tilted = abs(reading.pitch) > 20f || abs(reading.roll) > 20f
    val interference = reading.fieldStrength > 0f &&
        (reading.fieldStrength < 22f || reading.fieldStrength > 70f)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = if (referenceIsTrue) "TRUE NORTH" else "MAGNETIC NORTH",
            color = Brass,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 3.sp
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            CompassRose(
                heading = heading,
                pitch = reading.pitch,
                roll = reading.roll,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
            )

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "${heading.roundToInt() % 360}°",
                    color = Bone,
                    fontSize = 64.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = CompassEngine.cardinal(heading),
                    color = Brass,
                    fontSize = 20.sp,
                    letterSpacing = 6.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        StatusPanel(
            reading = reading,
            referenceIsTrue = referenceIsTrue,
            tilted = tilted,
            interference = interference
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            if (!reading.hasDeclination && !hasLocationPermission) {
                Button(
                    onClick = onRequestLocation,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Brass,
                        contentColor = Night
                    )
                ) {
                    Text("Use location for true north")
                }
            } else if (reading.hasDeclination) {
                Button(
                    onClick = { useTrueNorth = !useTrueNorth },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Housing,
                        contentColor = Bone
                    )
                ) {
                    Text(
                        if (referenceIsTrue) "Show magnetic north"
                        else "Show true north"
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusPanel(
    reading: CompassReading,
    referenceIsTrue: Boolean,
    tilted: Boolean,
    interference: Boolean
) {
    val calibration = when (reading.calibration) {
        SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> "Calibration high" to Good
        SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> "Calibration medium" to Warn
        SensorManager.SENSOR_STATUS_ACCURACY_LOW -> "Calibration low" to Warn
        else -> "Not calibrated" to NorthRed
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatusRow(calibration.first, calibration.second)

        if (reading.hasDeclination) {
            val d = reading.declination
            val direction = if (d >= 0f) "east" else "west"
            StatusRow(
                "Declination ${"%.1f".format(abs(d))}° $direction" +
                    (if (referenceIsTrue) ", applied" else ", not applied"),
                Brass
            )
        } else {
            StatusRow("No position fix — showing magnetic north", Brass)
        }

        if (reading.fieldStrength > 0f) {
            StatusRow("Field ${reading.fieldStrength.roundToInt()} µT", Brass)
        }

        if (reading.calibration <= SensorManager.SENSOR_STATUS_ACCURACY_LOW) {
            StatusRow("Trace a figure-8 with the phone to calibrate", Bone)
        }
        if (interference) {
            StatusRow("Metal or magnets nearby — step away and re-check", NorthRed)
        }
        if (tilted) {
            StatusRow("Hold the phone flat", Warn)
        }
    }
}

@Composable
private fun StatusRow(text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = text,
            color = color,
            fontSize = 13.sp,
            modifier = Modifier.padding(start = 10.dp)
        )
    }
}

@Composable
private fun CompassRose(
    heading: Float,
    pitch: Float,
    roll: Float,
    modifier: Modifier = Modifier
) {
    val numeralPaint = remember {
        NativePaint().apply {
            isAntiAlias = true
            textAlign = NativePaint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
    }
    val cardinalPaint = remember {
        NativePaint().apply {
            isAntiAlias = true
            textAlign = NativePaint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
    }

    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = min(cx, cy) * 0.96f

        drawCircle(Housing, radius, Offset(cx, cy))
        drawCircle(BrassDim, radius, Offset(cx, cy), style = Stroke(width = 2.dp.toPx()))
        drawCircle(BrassDim, radius * 0.60f, Offset(cx, cy), style = Stroke(width = 1.dp.toPx()))

        rotate(degrees = -heading, pivot = Offset(cx, cy)) {
            for (deg in 0 until 360 step 2) {
                val isMajor = deg % 30 == 0
                val isMedium = deg % 10 == 0
                val length = when {
                    isMajor -> radius * 0.11f
                    isMedium -> radius * 0.07f
                    else -> radius * 0.035f
                }
                drawLine(
                    color = if (isMajor) Brass else BrassDim,
                    start = polar(cx, cy, radius, deg.toFloat()),
                    end = polar(cx, cy, radius - length, deg.toFloat()),
                    strokeWidth = if (isMajor) 2.5.dp.toPx() else 1.dp.toPx()
                )
            }

            val canvas = drawContext.canvas.nativeCanvas
            numeralPaint.textSize = radius * 0.095f
            numeralPaint.color = Brass.toArgb()
            cardinalPaint.textSize = radius * 0.16f

            for (deg in 0 until 360 step 30) {
                val isCardinal = deg % 90 == 0
                val label = when (deg) {
                    0 -> "N"
                    90 -> "E"
                    180 -> "S"
                    270 -> "W"
                    else -> deg.toString()
                }
                val paint = if (isCardinal) cardinalPaint else numeralPaint
                if (isCardinal) {
                    paint.color = if (deg == 0) NorthRed.toArgb() else Bone.toArgb()
                }
                canvas.save()
                canvas.rotate(deg.toFloat(), cx, cy)
                val baseline = cy - radius + radius * (if (isCardinal) 0.32f else 0.26f)
                canvas.drawText(label, cx, baseline, paint)
                canvas.restore()
            }

            val needle = Path().apply {
                moveTo(cx, cy - radius * 0.58f)
                lineTo(cx - radius * 0.045f, cy - radius * 0.40f)
                lineTo(cx + radius * 0.045f, cy - radius * 0.40f)
                close()
            }
            drawPath(needle, NorthRed)
        }

        val index = Path().apply {
            moveTo(cx, cy - radius * 0.80f)
            lineTo(cx - radius * 0.045f, cy - radius * 0.90f)
            lineTo(cx + radius * 0.045f, cy - radius * 0.90f)
            close()
        }
        drawPath(index, Bone)

        val levelCenter = Offset(cx, cy + radius * 0.40f)
        val levelRadius = radius * 0.11f
        drawCircle(BrassDim, levelRadius, levelCenter, style = Stroke(width = 1.dp.toPx()))
        val level = abs(pitch) < 8f && abs(roll) < 8f
        drawCircle(
            color = if (level) Good else Warn,
            radius = levelRadius * 0.30f,
            center = Offset(
                levelCenter.x - (roll.coerceIn(-20f, 20f) / 20f) * levelRadius * 0.65f,
                levelCenter.y - (pitch.coerceIn(-20f, 20f) / 20f) * levelRadius * 0.65f
            )
        )
    }
}

private fun DrawScope.polar(cx: Float, cy: Float, radius: Float, degrees: Float): Offset {
    val radians = Math.toRadians(degrees.toDouble() - 90.0)
    return Offset(
        cx + radius * cos(radians).toFloat(),
        cy + radius * sin(radians).toFloat()
    )
}
