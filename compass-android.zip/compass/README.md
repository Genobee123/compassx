# Compass

An accurate compass for the Galaxy S23 Ultra. Reads the phone's fused
rotation-vector sensor, corrects magnetic north to true north using your local
declination, and tells you when the reading should not be trusted.

## Getting an APK on your phone

### Route A — GitHub builds it for you (no PC software)

1. Create a new **public** repo on github.com.
2. Upload the contents of this folder to it (Add file → Upload files; drag the
   whole folder in, including the hidden `.github` folder).
3. Open the **Actions** tab and let the "Build APK" job run. It takes 3–6 minutes.
4. When it finishes, go to **Releases** in the sidebar. The `app-debug.apk` there
   is a direct download — tap it on your phone.

If you upload through the web UI, the workflow handles the missing execute bit on
`gradlew` for you.

### Route B — Android Studio on a PC

1. Open the folder in Android Studio (Koala or newer).
2. Let it sync — it downloads Gradle 8.9 and the Android SDK bits on its own.
3. Build → Build Bundle(s) / APK(s) → Build APK(s), or plug the phone in and hit Run.

### Installing it

The APK is not from the Play Store, so Android asks once. Open the file, tap
**Settings** on the prompt, allow the app you're installing from (Files, Chrome,
Drive) to install unknown apps, then back out and tap Install.

## How the heading is worked out

- **Sensor**: `TYPE_ROTATION_VECTOR`, the fused magnetometer + gyroscope +
  accelerometer estimate. Much steadier than raw magnetometer readings, and it
  does not swing when you move the phone.
- **Declination**: `GeomagneticField` converts magnetic north to true north for
  your latitude and longitude. In Canada this correction runs from a few degrees
  to over 20 — ignoring it is the single biggest error in most compass apps.
  Location permission is optional; without it the app plainly says it is showing
  magnetic north.
- **Smoothing**: shortest-path interpolation, so the dial never spins the long
  way round when the heading crosses 360°.
- **Calibration**: the magnetometer reports its own confidence. Anything below
  "high" gets a prompt to trace a figure-8.
- **Interference**: Earth's field is roughly 25–65 µT. Readings outside that mean
  something nearby is bending the field — car body, speaker, magnetic case, desk
  frame. The app flags it instead of quietly lying to you.
- **Tilt**: heading accuracy degrades as the phone tilts, so there's a bubble
  level in the dial and a warning past 20°.

## Accuracy notes for the S23 Ultra

- The S Pen and magnetic cases sit close to the magnetometer. If the heading is
  stubbornly off, pull the pen and take the case off, then recalibrate.
- Calibrate away from vehicles and desks. Steel reinforcement in floors and
  concrete throws readings off by tens of degrees.
- Compare against a known bearing once — a straight road on a map — to confirm
  the declination correction is being applied the right way for your area.

## Project layout

```
app/src/main/java/com/genobee/compass/
  MainActivity.kt     activity, permission, sensor lifecycle
  CompassEngine.kt    sensor fusion, declination, calibration state
  CompassScreen.kt    the dial and readouts
.github/workflows/
  build-apk.yml       cloud build that produces the downloadable APK
```
